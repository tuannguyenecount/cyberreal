<link type="text/css" rel="stylesheet"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/style1c1d.css?ver=222"/>
  <link type="text/css" rel="stylesheet"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/sub.css"/>
  <link type="text/css" rel="stylesheet"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/content.css"/>
  <link type="text/css" rel="stylesheet"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/j-navigation.css"/>
  <link type="text/css" rel="stylesheet"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/detailnews.css"/>
  <link rel="stylesheet" type="text/css"
     href="<?=base_url?>/img.zing.vn/volamthuphi/skin/jxthuphi_2014_06/css/listevent.css"/>
  <link type="text/css" rel="stylesheet" href="<?=base_url?>/css/apprise.css"/>
  <script language="javascript" src="<?=base_url?>/css/apprise-1.5.full.js"></script>
    <link rel="stylesheet" type="text/css"
     href="<?=base_url?>/css/subpage.css"/>
  <style>
    
  </style> 
 