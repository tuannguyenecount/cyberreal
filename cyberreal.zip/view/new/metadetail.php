<meta name="title" content="<?= $view_data['model']['SeoTitle'] ?>" />
<meta name="description" content="<?= $view_data['model']['SeoDescription'] ?>" />
<meta name="keyword" content="<?= $view_data['model']['SeoKeyword'] ?>" />
