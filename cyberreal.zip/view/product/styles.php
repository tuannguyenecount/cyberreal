<link href="<?= base_url ?>/js/slick/slick.css" rel="stylesheet">
<style>
	#formhotro{
		padding:15px 20px 15px;background-color:#fff;border:1px solid #ddd;box-shadow:2px 2px 10px 0 rgba(0,0,0,0.05)
	}
	.full-width, .expand {
	    width: 100% !important;
	    max-width: 100% !important;
	    padding-left: 0 !important;
	    padding-right: 0 !important;
	    display: block;
	}
	.well {
	  min-height: 20px;
	  padding: 19px;
	  margin-bottom: 20px;
	  background-color: #f5f5f5;
	  border: 1px solid #e3e3e3;
	  border-radius: 4px;
	  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
	  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.05);
	}
	.well blockquote {
	  border-color: #ddd;
	  border-color: rgba(0, 0, 0, 0.15);
	}
	.well-lg {
	  padding: 24px;
	  border-radius: 6px;
	}
	.well-sm {
	  padding: 9px;
	  border-radius: 3px;
	}
	.border-radius-none{
		border-radius: 0;
	}
</style>