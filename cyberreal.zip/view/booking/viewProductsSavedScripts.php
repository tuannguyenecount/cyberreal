<script src='https://www.google.com/recaptcha/api.js'></script>
<link rel="stylesheet" href="<?= base_url ?>/js/DatePicker/themes/jquery-ui.css">
<script src="<?= base_url ?>/js/DatePicker/jquery-ui.js"></script>
<script src="<?= base_url ?>/js/DatePicker/jquery.ui.datepicker-vi.js"></script>
<script type="text/javascript">
  $(function() {
        $( ".calendar" ).datepicker( $.datepicker.regional[ "vi" ] );
   });
</script>
