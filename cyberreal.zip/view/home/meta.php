<meta name="title" content="<?= $_SESSION['InfoWeb']['SeoTitle'] ?>" />
<meta name="description" content="<?= $_SESSION['InfoWeb']['SeoDescription'] ?>" />
<meta name="keyword" content="<?= $_SESSION['InfoWeb']['SeoKeyword'] ?>" />

<meta property="fb:app_id" content="<?= $_SESSION['InfoWeb']['OgFacebookId'] ?>" />
<meta property="og:url" content="<?= base_url ?>" />
<meta property="og:type" content="website" />
<meta property="og:title" content="<?= $_SESSION['InfoWeb']['OgTitle'] ?>" />
<meta property="og:description" content="<?= $_SESSION['InfoWeb']['OgDescription'] ?>" />
<meta property="og:site_name" content="<?= $_SESSION['InfoWeb']['OgSiteName'] ?>" />
<meta property="og:image" content="<?= $_SESSION['InfoWeb']['OgImage'] ?>" />