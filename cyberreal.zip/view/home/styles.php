<style>
	.box-text { 
		padding-top:.7em;padding-bottom:1.4em;position:relative;width:100%;  
	}
	.is-divider {
		margin-top:.5em;margin-bottom:.5em;height:2px;
		display: block;
	    background-color: rgba(0,0,0,0.1);
	    margin: 1em 0 1em;
	    width: 100%;
	    max-width: 30px;
	}
	.box-text p{margin-top:.1em;margin-bottom:.1em}
</style> 