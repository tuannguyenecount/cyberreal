<?php 
  switch($action)
  {
//    case "errorlog":
//    {
//      $view_data['title'] = "Nhật ký error";
//      $view_data['view_name'] = "log/errorlog.php";  
//      $view_data['model'] = file_get_contents(SITE_PATH."/log/errors.txt");
//      break;
//    }  
  }

?>