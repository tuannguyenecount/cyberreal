<div class="text-center">
    <p class="p-2 fs-18">
	        Căn hộ đã được lưu vào danh sách hẹn đi xem thành công.
	    </p>

    <div class="form-group btn-group-sm">
		<button type="button" class="btn btn-secondary text-white" data-dismiss="modal">Thêm căn hộ khác</button>
		<a class="btn btn-primary" href="<?= base_url ?>/hen-di-xem.html">Xem danh sách</a>    </div>
</div>