<?php 
  switch($action)
  {
    case "index":
    {
      $view_data['title'] = "Home";
      $view_data['view_name'] = "home/index.php";  
      break;
    }  
  }
