<link rel="stylesheet" href="bower_components/datatables.net-bs/css/dataTables.bootstrap.min.css">
<style>
	#box-tools-custom{
			margin-top:-55px;
			float:right;
			padding:10px;
		}
	@media screen and (max-width: 992px){
		#box-tools-custom{
			margin-top:10px;
			clear: both;
			float:left;
		}
	}
</style>