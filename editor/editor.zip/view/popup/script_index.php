 	<script src="<?=base_url?>/editor/ckeditor/ckeditor.js"></script>
    <script type="text/javascript" src="<?=base_url?>/editor/ckfinder/ckfinder.js"></script>
    <script>
        CKEDITOR.replace("Content");
        CKFinder.setupCKEditor(null, '<?=base_url?>/editor/ckfinder');
    </script>