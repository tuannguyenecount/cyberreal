<link href="<?=base_url?>/assets/css/jquery.niftymodals.css" rel="stylesheet" />
