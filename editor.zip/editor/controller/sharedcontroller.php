<?php 
 
  switch($action)
  {
  	case "vn_to_str":
  	{
  		echo vn_to_str($_POST['vnstring']);
  		exit();
  	}
    
  }

?>